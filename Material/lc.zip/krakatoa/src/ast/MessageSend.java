package ast;


abstract class MessageSend  extends Expr  {
}

