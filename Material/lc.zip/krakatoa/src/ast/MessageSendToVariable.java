package ast;


public class MessageSendToVariable extends MessageSend { 

    public Type getType() { 
        return null;
    }
    
    public void genC( PW pw, boolean putParenthesis ) {
        
    }

    
}    